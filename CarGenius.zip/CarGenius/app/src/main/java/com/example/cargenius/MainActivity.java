package com.example.cargenius;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    static ArrayList<Integer> randomGenerated = new ArrayList<Integer>();
    static ArrayList<String> hintDashes = new ArrayList<String>();
    static ArrayList<Integer> randomCars = new ArrayList<Integer>();
    static ArrayList<String> randomCarNames = new ArrayList<String>();
    static int guessNotPresent = 0;
    static int invalidGuesses = 0;
    static int imgCount = 0;
    static int incorrectGuesses = 0;
    static int totSco = 0;
    static int switchOn = 0;

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("switch_on", switchOn);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        switchOn = savedInstanceState.getInt("switch_on");
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#c95500"));
        actionBar.setBackgroundDrawable(colorDrawable);

        Button switchBtn = (Button) findViewById(R.id.switch_btn);

        if (switchOn == 0) {
            switchBtn.setText("Off");
            switchBtn.setTextColor(Color.parseColor("#e00000"));
        } else {
            switchBtn.setText("On");
            switchBtn.setTextColor(Color.parseColor("#10c200"));
        }
    }

    public void launchCarMakeActivity(View view) {
        randomGenerated.clear();
        startActivity(new Intent(MainActivity.this, CarMakeActivity.class));
    }

    public void launchHintsActivity(View view) {
        randomGenerated.clear();
        hintDashes.clear();
        guessNotPresent = 0;
        invalidGuesses = 0;
        startActivity(new Intent(MainActivity.this, HintsActivity.class));
    }

    public void launchCarImageActivity(View view) {
        randomCars.clear();
        imgCount = 0;
        startActivity(new Intent(MainActivity.this, CarImageActivity.class));
    }

    public void launchAdvancedLevelActivity(View view) {
        randomCars.clear();
        incorrectGuesses = 0;
        startActivity(new Intent(MainActivity.this, AdvancedLevelActivity.class));
    }

    @SuppressLint("SetTextI18n")
    public void switchPress(View view) {

        Button switchBtn = (Button) findViewById(R.id.switch_btn);

        if (switchOn == 0) {
            switchOn = 1;
            switchBtn.setText("On");
            switchBtn.setTextColor(Color.parseColor("#00db07"));
        } else {
            switchOn = 0;
            switchBtn.setText("Off");
            switchBtn.setTextColor(Color.parseColor("#e00000"));
        }
    }
}