package com.example.cargenius;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class CarMakeActivity extends AppCompatActivity {

    Random random = new Random();
    Integer[] images = {
            R.drawable.car_1,
            R.drawable.car_2,
            R.drawable.car_3,
            R.drawable.car_4,
            R.drawable.car_5,
            R.drawable.car_6,
            R.drawable.car_7,
            R.drawable.car_8,
            R.drawable.car_9,
            R.drawable.car_10,
            R.drawable.car_11,
            R.drawable.car_12,
            R.drawable.car_13,
            R.drawable.car_14,
            R.drawable.car_15,
            R.drawable.car_16,
            R.drawable.car_17,
            R.drawable.car_18,
            R.drawable.car_19,
            R.drawable.car_20,
            R.drawable.car_21,
            R.drawable.car_22,
            R.drawable.car_23,
            R.drawable.car_24,
            R.drawable.car_25,
            R.drawable.car_26,
            R.drawable.car_27,
            R.drawable.car_28,
            R.drawable.car_29,
            R.drawable.car_30,
    };

    String[] carMakes = {
            "Audi",
            "Audi",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Chevrolet",
            "Dodge",
            "Ford",
            "Honda",
            "Honda",
            "Koenigsegg",
            "Lamborghini",
            "Lamborghini",
            "Lamborghini",
            "Mazda",
            "Mazda",
            "McLaren",
            "McLaren",
            "Mercedes",
            "Mitsubishi",
            "Nissan",
            "Nissan",
            "Nissan",
            "Nissan",
            "Porsche",
            "Porsche",
            "Subaru",
            "Toyota",
            "Toyota",
            "Toyota"
    };

    String[] spinnerCarMakes = {
            "Audi",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Dodge",
            "Ford",
            "Honda",
            "Koenigsegg",
            "Lamborghini",
            "Mazda",
            "McLaren",
            "Mercedes",
            "Mitsubishi",
            "Nissan",
            "Porsche",
            "Subaru",
            "Toyota"
    };

    int randomCar;
    String carMakeChosen;
    String identifyNextText = "Identify";
    String correctOrWrong = "";
    String correctMake = "";
    long milliRemaining;

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putString("car_make_chosen", carMakeChosen);
        bundle.putInt("random_car", randomCar);
        bundle.putString("identify_next_text", identifyNextText);
        bundle.putString("correct_wrong", correctOrWrong);
        bundle.putString("correct_make", correctMake);
        bundle.putLong("milli_remaining", milliRemaining);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_make);

        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#c95500"));
        actionBar.setBackgroundDrawable(colorDrawable);

        final ImageView imgView = (ImageView) findViewById(R.id.car_make_img);
        Button identifyBtn = (Button) findViewById(R.id.identify_next_button);
        TextView correctWrong = (TextView) findViewById(R.id.correct_wrong_textView);
        TextView correctMakeTextView = (TextView) findViewById(R.id.correct_car_make);
        final TextView makeTimer = (TextView) findViewById(R.id.make_timer);

        if (MainActivity.randomGenerated.size() == 30) {
            MainActivity.randomGenerated.clear();
            startActivity(new Intent(CarMakeActivity.this, MainActivity.class));
        }

        if (savedInstanceState != null) {

            carMakeChosen = savedInstanceState.getString("car_make_chosen");
            randomCar = savedInstanceState.getInt("random_car");
            identifyNextText = savedInstanceState.getString("identify_next_text");
            correctOrWrong = savedInstanceState.getString("correct_wrong");
            correctMake = savedInstanceState.getString("correct_make");
            milliRemaining = savedInstanceState.getLong("milli_remaining");

            identifyBtn.setText(identifyNextText);
            correctWrong.setText(correctOrWrong);
            correctMakeTextView.setText(correctMake);

            if (MainActivity.switchOn == 1) {

                new CountDownTimer(milliRemaining, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        makeTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        makeTimer.setText("Time Up!");
                        makeCountdownTimer();
                    }
                }.start();
            }

            if (correctWrong.getText().equals("CORRECT!")) {
                correctWrong.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrong.setTextColor(Color.parseColor("#d10000"));
                correctMakeTextView.setTextColor(Color.parseColor("#bfb900"));
            }
        } else {

            if (MainActivity.switchOn == 1) {
                new CountDownTimer(20000, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        makeTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        makeTimer.setText("Time Up!");
                        makeCountdownTimer();
                    }
                }.start();
            }

            randomCar = random.nextInt(images.length);

            while (MainActivity.randomGenerated.contains(randomCar)) {
                randomCar = random.nextInt(images.length);
            }

            MainActivity.randomGenerated.add(randomCar);
        }

        imgView.setImageResource(images[randomCar]);

        Spinner dropdown = (Spinner) findViewById(R.id.car_name_spinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, spinnerCarMakes);
        dropdown.setAdapter(adapter);
    }

    @SuppressLint("SetTextI18n")
    public void makeCountdownTimer() {

        Spinner spinner = (Spinner) findViewById(R.id.car_name_spinner);
        carMakeChosen = spinner.getSelectedItem().toString();
        final TextView makeTimer = (TextView) findViewById(R.id.make_timer);
        Button identifyNext = (Button) findViewById(R.id.identify_next_button);

        identifyNextText = identifyNext.getText().toString();

        if (identifyNext.getText().equals("Identify")) {
            for (int i = 0; i < carMakes.length; i++) {
                if (i == randomCar) {
                    TextView correctWrongTextView = (TextView) findViewById(R.id.correct_wrong_textView);

                    if (carMakeChosen.equals(carMakes[i])) {
                        correctWrongTextView.setText("CORRECT!");
                        correctWrongTextView.setTextColor(Color.parseColor("#07d100"));
                    } else {
                        correctWrongTextView.setText("WRONG!");
                        correctWrongTextView.setTextColor(Color.parseColor("#d10000"));

                        TextView correctCarMake = (TextView) findViewById(R.id.correct_car_make);
                        correctCarMake.setText("Correct car make : " + carMakes[i]);
                        correctMake = correctCarMake.getText().toString();
                        correctCarMake.setTextColor(Color.parseColor("#bfb900"));
                    }

                    correctOrWrong = correctWrongTextView.getText().toString();
                    identifyNext.setText("Next");
                    identifyNextText = identifyNext.getText().toString();
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    public void identifyCar(View view) {

        Spinner spinner = (Spinner) findViewById(R.id.car_name_spinner);
        carMakeChosen = spinner.getSelectedItem().toString();
        final TextView makeTimer = (TextView) findViewById(R.id.make_timer);
        Button identifyNext = (Button) findViewById(R.id.identify_next_button);

        identifyNextText = identifyNext.getText().toString();

        if (identifyNext.getText().equals("Identify")) {
            for (int i = 0; i < carMakes.length; i++) {
                if (i == randomCar) {
                    TextView correctWrongTextView = (TextView) findViewById(R.id.correct_wrong_textView);

                    if (carMakeChosen.equals(carMakes[i])) {
                        correctWrongTextView.setText("CORRECT!");
                        correctWrongTextView.setTextColor(Color.parseColor("#07d100"));
                    } else {
                        correctWrongTextView.setText("WRONG!");
                        correctWrongTextView.setTextColor(Color.parseColor("#d10000"));

                        TextView correctCarMake = (TextView) findViewById(R.id.correct_car_make);
                        correctCarMake.setText("Correct car make : " + carMakes[i]);
                        correctMake = correctCarMake.getText().toString();
                        correctCarMake.setTextColor(Color.parseColor("#bfb900"));
                    }

                    correctOrWrong = correctWrongTextView.getText().toString();
                    identifyNext.setText("Next");
                    identifyNextText = identifyNext.getText().toString();
                }
            }
        } else if (identifyNext.getText().equals("Next")) {
            startActivity(new Intent(CarMakeActivity.this, CarMakeActivity.class));
        }
    }
}