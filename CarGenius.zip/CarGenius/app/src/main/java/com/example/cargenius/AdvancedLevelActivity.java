package com.example.cargenius;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class AdvancedLevelActivity extends AppCompatActivity {

    Random random = new Random();

    Integer[] images = {
            R.drawable.car_1,
            R.drawable.car_2,
            R.drawable.car_3,
            R.drawable.car_4,
            R.drawable.car_5,
            R.drawable.car_6,
            R.drawable.car_7,
            R.drawable.car_8,
            R.drawable.car_9,
            R.drawable.car_10,
            R.drawable.car_11,
            R.drawable.car_12,
            R.drawable.car_13,
            R.drawable.car_14,
            R.drawable.car_15,
            R.drawable.car_16,
            R.drawable.car_17,
            R.drawable.car_18,
            R.drawable.car_19,
            R.drawable.car_20,
            R.drawable.car_21,
            R.drawable.car_22,
            R.drawable.car_23,
            R.drawable.car_24,
            R.drawable.car_25,
            R.drawable.car_26,
            R.drawable.car_27,
            R.drawable.car_28,
            R.drawable.car_29,
            R.drawable.car_30,
    };

    String[] carMakes = {
            "Audi",
            "Audi",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Chevrolet",
            "Dodge",
            "Ford",
            "Honda",
            "Honda",
            "Koenigsegg",
            "Lamborghini",
            "Lamborghini",
            "Lamborghini",
            "Mazda",
            "Mazda",
            "McLaren",
            "McLaren",
            "Mercedes",
            "Mitsubishi",
            "Nissan",
            "Nissan",
            "Nissan",
            "Nissan",
            "Porsche",
            "Porsche",
            "Subaru",
            "Toyota",
            "Toyota",
            "Toyota"
    };

    int randomCar;
    int randomCar1;
    int randomCar2;
    int randomCar3;
    String editText1 = "Image 1 Car Make";
    String editText2 = "Image 2 Car Make";
    String editText3 = "Image 3 Car Make";
    String advSubmitNext = "Submit";
    String correctMake1Value = "";
    String correctMake2Value = "";
    String correctMake3Value = "";
    String advCorrectWrongValue = "";
    int currentScore = 0;
    //long milliRemaining;

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);

        bundle.putInt("random_car", randomCar);
        bundle.putInt("random_car_1", randomCar1);
        bundle.putInt("random_car_2", randomCar2);
        bundle.putInt("random_car_3", randomCar3);
        bundle.putString("edit_text_1", editText1);
        bundle.putString("edit_text_2", editText2);
        bundle.putString("edit_text_3", editText3);
        bundle.putString("adv_submit_next", advSubmitNext);
        bundle.putString("correct_make_1", correctMake1Value);
        bundle.putString("correct_make_2", correctMake2Value);
        bundle.putString("correct_make_3", correctMake3Value);
        bundle.putString("adv_correct_wrong", advCorrectWrongValue);
        bundle.putInt("current_score", currentScore);
        //bundle.putLong("milli_remaining", milliRemaining);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_level);

        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#c95500"));
        actionBar.setBackgroundDrawable(colorDrawable);

        final ImageView advImg1 = (ImageView) findViewById(R.id.adv_image_1);
        final ImageView advImg2 = (ImageView) findViewById(R.id.adv_image_2);
        final ImageView advImg3 = (ImageView) findViewById(R.id.adv_image_3);
        EditText car1Guess = (EditText) findViewById(R.id.adv_tb_1);
        EditText car2Guess = (EditText) findViewById(R.id.adv_tb_2);
        EditText car3Guess = (EditText) findViewById(R.id.adv_tb_3);
        TextView correctMake1 = (TextView) findViewById(R.id.correct_make_1);
        TextView correctMake2 = (TextView) findViewById(R.id.correct_make_2);
        TextView correctMake3 = (TextView) findViewById(R.id.correct_make_3);
        TextView advCorrectWrong = (TextView) findViewById(R.id.adv_correct_wrong);
        TextView advScore = (TextView) findViewById(R.id.adv_score);
        Button advSubNext = (Button) findViewById(R.id.adv_next_submit);
        //TextView advTimer = (TextView) findViewById(R.id.adv_timer);

        if (savedInstanceState != null) {

            randomCar = savedInstanceState.getInt("random_car");
            randomCar1 = savedInstanceState.getInt("random_car_1");
            randomCar2 = savedInstanceState.getInt("random_car_2");
            randomCar3 = savedInstanceState.getInt("random_car_3");
            editText1 = savedInstanceState.getString("edit_text_1");
            editText2 = savedInstanceState.getString("edit_text_2");
            editText3 = savedInstanceState.getString("edit_text_3");
            advSubmitNext = savedInstanceState.getString("adv_submit_next");
            correctMake1Value = savedInstanceState.getString("correct_make_1");
            correctMake2Value = savedInstanceState.getString("correct_make_2");
            correctMake3Value = savedInstanceState.getString("correct_make_3");
            advCorrectWrongValue = savedInstanceState.getString("adv_correct_wrong");
            currentScore = savedInstanceState.getInt("current_score");
            //milliRemaining = savedInstanceState.getLong("milli_remaining");

            correctMake1.setText(correctMake1Value);
            correctMake2.setText(correctMake2Value);
            correctMake3.setText(correctMake3Value);
            advCorrectWrong.setText(advCorrectWrongValue);
            advScore.setText("Score : " + MainActivity.totSco);
            advSubNext.setText(advSubmitNext);

//            if (advTimer.getText().equals("Time Up!") && milliRemaining == 0) {
//                milliRemaining = 20000;
//            }
//
//            if (MainActivity.switchOn == 1) {
//
//                new CountDownTimer(milliRemaining, 1000) {
//
//                    @SuppressLint("SetTextI18n")
//                    public void onTick(long millisUntilFinished) {
//                        advTimer.setText("Timer : " + millisUntilFinished / 1000);
//                        milliRemaining = millisUntilFinished;
//                    }
//
//                    @SuppressLint("SetTextI18n")
//                    public void onFinish() {
//                        advTimer.setText("Time Up!");
//                        advSubmitNext(advSubNext);
//                        //advCountdownTimer();
//                    }
//                }.start();
//            }

            if (currentScore == 3) {

                advSubNext.setText("Next");
                advCorrectWrong.setText("CORRECT!");
                advCorrectWrong.setTextColor(Color.parseColor("#07d100"));

                car1Guess.setBackgroundColor(Color.parseColor("#008a02"));
                car1Guess.setTextColor(Color.parseColor("#ffffff"));
                car1Guess.setEnabled(false);

                car2Guess.setBackgroundColor(Color.parseColor("#008a02"));
                car2Guess.setTextColor(Color.parseColor("#ffffff"));
                car2Guess.setEnabled(false);

                car3Guess.setBackgroundColor(Color.parseColor("#008a02"));
                car3Guess.setTextColor(Color.parseColor("#ffffff"));
                car3Guess.setEnabled(false);

            } else {

                if (editText1.equalsIgnoreCase(carMakes[randomCar1])) {

                    car1Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car1Guess.setTextColor(Color.parseColor("#ffffff"));
                    car1Guess.setEnabled(false);

                } else if (!editText1.equals("Image 1 Car Make") || MainActivity.incorrectGuesses == 3) {

                    car1Guess.setText("Guess again!");
                    car1Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car1Guess.setTextColor(Color.parseColor("#ffffff"));
                }

                if (editText2.equalsIgnoreCase(carMakes[randomCar2])) {

                    car2Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car2Guess.setTextColor(Color.parseColor("#ffffff"));
                    car2Guess.setEnabled(false);

                } else if (!editText2.equals("Image 2 Car Make") || MainActivity.incorrectGuesses == 3) {

                    car2Guess.setText("Guess again!");
                    car2Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car2Guess.setTextColor(Color.parseColor("#ffffff"));
                }

                if (editText3.equalsIgnoreCase(carMakes[randomCar3])) {

                    car3Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car3Guess.setTextColor(Color.parseColor("#ffffff"));
                    car3Guess.setEnabled(false);

                } else if (!editText3.equals("Image 3 Car Make") || MainActivity.incorrectGuesses == 3) {

                    car3Guess.setText("Guess again!");
                    car3Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car3Guess.setTextColor(Color.parseColor("#ffffff"));
                }

                if (MainActivity.incorrectGuesses == 3) {

                    advSubNext.setText("Next");

                    if (car1Guess.isEnabled()) {
                        car1Guess.setEnabled(false);
                        correctMake1.setText(carMakes[randomCar1]);
                        correctMake1.setTextColor(Color.parseColor("#bfb900"));
                    }

                    if (car2Guess.isEnabled()) {
                        car2Guess.setEnabled(false);
                        correctMake2.setText(carMakes[randomCar2]);
                        correctMake2.setTextColor(Color.parseColor("#bfb900"));
                    }

                    if (car3Guess.isEnabled()) {
                        car3Guess.setEnabled(false);
                        correctMake3.setText(carMakes[randomCar3]);
                        correctMake3.setTextColor(Color.parseColor("#bfb900"));
                    }

                    advCorrectWrong.setText("WRONG!");
                    advCorrectWrong.setTextColor(Color.parseColor("#d10000"));
                }
            }
        } else {

//            if (MainActivity.switchOn == 1) {
//                new CountDownTimer(20000, 1000) {
//
//                    @SuppressLint("SetTextI18n")
//                    public void onTick(long millisUntilFinished) {
//                        advTimer.setText("Timer : " + millisUntilFinished / 1000);
//                        milliRemaining = millisUntilFinished;
//                    }
//
//                    @SuppressLint("SetTextI18n")
//                    public void onFinish() {
//                        advTimer.setText("Time Up!");
//                        advSubmitNext(advSubNext);
//                    }
//                }.start();
//            }

            advScore.setText("Score : " + MainActivity.totSco);

            for (int i = 0; i < 3; i++) {
                randomCar = random.nextInt(images.length);

                if (i > 0) {
                    for (int i2 = 0; i2 < MainActivity.randomCarNames.size(); i2++) {
                        if (MainActivity.randomCarNames.get(i2).equals(carMakes[randomCar])) {
                            randomCar = random.nextInt(images.length);
                        }
                    }
                }

                while (MainActivity.randomCars.contains(randomCar)) {
                    randomCar = random.nextInt(images.length);

                    if (i > 0) {
                        for (int i2 = 0; i2 < MainActivity.randomCarNames.size(); i2++) {
                            if (MainActivity.randomCarNames.get(i2).equals(carMakes[randomCar])) {
                                randomCar = random.nextInt(images.length);
                            }
                        }
                    }
                }

                MainActivity.randomCars.add(randomCar);
                MainActivity.randomCarNames.add(carMakes[randomCar]);

                if (i == 0) {
                    randomCar1 = randomCar;
                } else if (i == 1) {
                    randomCar2 = randomCar;
                } else {
                    randomCar3 = randomCar;
                }
            }
        }
        MainActivity.randomCarNames.clear();

        advImg1.setImageResource(images[randomCar1]);
        advImg2.setImageResource(images[randomCar2]);
        advImg3.setImageResource(images[randomCar3]);
    }

    @SuppressLint("SetTextI18n")
    public void advSubmitNext(View view) {

        EditText car1Guess = (EditText) findViewById(R.id.adv_tb_1);
        EditText car2Guess = (EditText) findViewById(R.id.adv_tb_2);
        EditText car3Guess = (EditText) findViewById(R.id.adv_tb_3);
        TextView correctMake1 = (TextView) findViewById(R.id.correct_make_1);
        TextView correctMake2 = (TextView) findViewById(R.id.correct_make_2);
        TextView correctMake3 = (TextView) findViewById(R.id.correct_make_3);
        TextView advCorrectWrong = (TextView) findViewById(R.id.adv_correct_wrong);
        TextView advScore = (TextView) findViewById(R.id.adv_score);
        Button advSubNext = (Button) findViewById(R.id.adv_next_submit);

        editText1 = car1Guess.getText().toString();
        editText2 = car2Guess.getText().toString();
        editText3 = car3Guess.getText().toString();

        if (advSubNext.getText().equals("Submit")) {

            if (car1Guess.isEnabled()) {
                if (car1Guess.getText().toString().equalsIgnoreCase(carMakes[randomCar1])) {
                    car1Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car1Guess.setTextColor(Color.parseColor("#ffffff"));
                    car1Guess.setEnabled(false);

                    currentScore += 1;
                    MainActivity.totSco += 1;
                    advScore.setText("Score : " + MainActivity.totSco);

                } else {
                    car1Guess.setText("Guess again!");
                    car1Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car1Guess.setTextColor(Color.parseColor("#ffffff"));

                    editText1 = car1Guess.getText().toString();
                }
            }

            if (car2Guess.isEnabled()) {
                if (car2Guess.getText().toString().equalsIgnoreCase(carMakes[randomCar2])) {
                    car2Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car2Guess.setTextColor(Color.parseColor("#ffffff"));
                    car2Guess.setEnabled(false);

                    currentScore += 1;
                    MainActivity.totSco += 1;
                    advScore.setText("Score : " + MainActivity.totSco);
                } else {
                    car2Guess.setText("Guess again!");
                    car2Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car2Guess.setTextColor(Color.parseColor("#ffffff"));

                    editText2 = car2Guess.getText().toString();
                }
            }

            if (car3Guess.isEnabled()) {
                if (car3Guess.getText().toString().equalsIgnoreCase(carMakes[randomCar3])) {
                    car3Guess.setBackgroundColor(Color.parseColor("#008a02"));
                    car3Guess.setTextColor(Color.parseColor("#ffffff"));
                    car3Guess.setEnabled(false);

                    currentScore += 1;
                    MainActivity.totSco += 1;
                    advScore.setText("Score : " + MainActivity.totSco);
                } else {
                    car3Guess.setText("Guess again!");
                    car3Guess.setBackgroundColor(Color.parseColor("#cc0000"));
                    car3Guess.setTextColor(Color.parseColor("#ffffff"));

                    editText3 = car3Guess.getText().toString();
                }
            }

            if (car1Guess.isEnabled() || car2Guess.isEnabled() || car3Guess.isEnabled()) {
                MainActivity.incorrectGuesses += 1;
            }
        } else {
            MainActivity.incorrectGuesses = 0;
            if (MainActivity.randomCars.size() >= 30) {
                MainActivity.randomCars.clear();
                MainActivity.totSco = 0;
                startActivity(new Intent(AdvancedLevelActivity.this, MainActivity.class));
            } else {
                startActivity(new Intent(AdvancedLevelActivity.this, AdvancedLevelActivity.class));
            }
        }

        if (currentScore == 3) {
            advSubNext.setText("Next");
            advCorrectWrong.setText("CORRECT!");
            advCorrectWrong.setTextColor(Color.parseColor("#07d100"));
        }

        if (MainActivity.incorrectGuesses == 3) {

            advSubNext.setText("Next");

            if (car1Guess.isEnabled()) {
                car1Guess.setEnabled(false);
                correctMake1.setText(carMakes[randomCar1]);
                correctMake1.setTextColor(Color.parseColor("#bfb900"));
            }

            if (car2Guess.isEnabled()) {
                car2Guess.setEnabled(false);
                correctMake2.setText(carMakes[randomCar2]);
                correctMake2.setTextColor(Color.parseColor("#bfb900"));
            }

            if (car3Guess.isEnabled()) {
                car3Guess.setEnabled(false);
                correctMake3.setText(carMakes[randomCar3]);
                correctMake3.setTextColor(Color.parseColor("#bfb900"));
            }

            advCorrectWrong.setText("WRONG!");
            advCorrectWrong.setTextColor(Color.parseColor("#d10000"));
        }
    }
}