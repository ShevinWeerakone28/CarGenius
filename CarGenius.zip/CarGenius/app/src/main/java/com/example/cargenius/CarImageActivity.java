package com.example.cargenius;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class CarImageActivity extends AppCompatActivity {

    Random random = new Random();

    Integer[] images = {
            R.drawable.car_1,
            R.drawable.car_2,
            R.drawable.car_3,
            R.drawable.car_4,
            R.drawable.car_5,
            R.drawable.car_6,
            R.drawable.car_7,
            R.drawable.car_8,
            R.drawable.car_9,
            R.drawable.car_10,
            R.drawable.car_11,
            R.drawable.car_12,
            R.drawable.car_13,
            R.drawable.car_14,
            R.drawable.car_15,
            R.drawable.car_16,
            R.drawable.car_17,
            R.drawable.car_18,
            R.drawable.car_19,
            R.drawable.car_20,
            R.drawable.car_21,
            R.drawable.car_22,
            R.drawable.car_23,
            R.drawable.car_24,
            R.drawable.car_25,
            R.drawable.car_26,
            R.drawable.car_27,
            R.drawable.car_28,
            R.drawable.car_29,
            R.drawable.car_30,
    };

    String[] carMakes = {
            "Audi",
            "Audi",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Chevrolet",
            "Dodge",
            "Ford",
            "Honda",
            "Honda",
            "Koenigsegg",
            "Lamborghini",
            "Lamborghini",
            "Lamborghini",
            "Mazda",
            "Mazda",
            "McLaren",
            "McLaren",
            "Mercedes",
            "Mitsubishi",
            "Nissan",
            "Nissan",
            "Nissan",
            "Nissan",
            "Porsche",
            "Porsche",
            "Subaru",
            "Toyota",
            "Toyota",
            "Toyota"
    };

    int randomCar;
    int randomCar1;
    int randomCar2;
    int randomCar3;
    int randomMake;
    String correctOrWrongClick = "";
    String carMakeGenerated = "";
    String correctImgMake = "";
    int clicked = 0;
    long milliRemaining;

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);

        bundle.putInt("random_car", randomCar);
        bundle.putInt("random_car_1", randomCar1);
        bundle.putInt("random_car_2", randomCar2);
        bundle.putInt("random_car_3", randomCar3);
        bundle.putInt("random_make", randomMake);
        bundle.putString("correct_wrong_click", correctOrWrongClick);
        bundle.putString("car_make_generated", carMakeGenerated);
        bundle.putString("correct_img_make", correctImgMake);
        bundle.putInt("click", clicked);
        bundle.putLong("milli_remaining", milliRemaining);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_image);

        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#c95500"));
        actionBar.setBackgroundDrawable(colorDrawable);

        final ImageView carImg1 = (ImageView) findViewById(R.id.car_image_1);
        final ImageView carImg2 = (ImageView) findViewById(R.id.car_image_2);
        final ImageView carImg3 = (ImageView) findViewById(R.id.car_image_3);
        TextView correctWrongImage = (TextView) findViewById(R.id.correct_wrong_image);
        TextView correctMakeImage = (TextView) findViewById(R.id.correct_make_image);
        TextView carMake = (TextView) findViewById(R.id.car_make_image);
        final TextView imageTimer = (TextView) findViewById(R.id.image_timer);

        if (savedInstanceState != null) {

            randomCar = savedInstanceState.getInt("random_car");
            randomCar1 = savedInstanceState.getInt("random_car_1");
            randomCar2 = savedInstanceState.getInt("random_car_2");
            randomCar3 = savedInstanceState.getInt("random_car_3");
            randomMake = savedInstanceState.getInt("random_make");
            correctOrWrongClick = savedInstanceState.getString("correct_wrong_click");
            carMakeGenerated = savedInstanceState.getString("car_make_generated");
            correctImgMake = savedInstanceState.getString("correct_img_make");
            clicked = savedInstanceState.getInt("click");
            milliRemaining = savedInstanceState.getLong("milli_remaining");

            correctWrongImage.setText(correctOrWrongClick);

            if (MainActivity.switchOn == 1) {

                new CountDownTimer(milliRemaining, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        imageTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        imageTimer.setText("Time Up!");

                        correctWrongImage.setText("WRONG!");
                        correctWrongImage.setTextColor(Color.parseColor("#d10000"));

                        correctMakeImage.setText("Correct image : " + (randomMake + 1));
                        correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                    }
                }.start();
            }

            if (correctWrongImage.getText().equals("CORRECT!")) {
                correctWrongImage.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongImage.setTextColor(Color.parseColor("#d10000"));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
            }

            if (correctWrongImage.getText().equals("CORRECT!")) {
                correctWrongImage.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongImage.setTextColor(Color.parseColor("#d10000"));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
            }

            if (clicked == 1) {
                correctMakeImage.setText("Correct image : " + (randomMake + 1));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                carImg1.setClickable(false);
                carImg2.setClickable(false);
                carImg3.setClickable(false);
            }
        } else {

            if (MainActivity.switchOn == 1) {

                new CountDownTimer(20000, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        imageTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        imageTimer.setText("Time Up!");

                        correctWrongImage.setText("WRONG!");
                        correctWrongImage.setTextColor(Color.parseColor("#d10000"));

                        correctMakeImage.setText("Correct image : " + (randomMake + 1));
                        correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                    }
                }.start();
            }

            for (int i = 0; i < 3; i++) {
                randomCar = random.nextInt(images.length);

                if (i > 0) {
                    for (int i2 = 0; i2 < MainActivity.randomCarNames.size(); i2++) {
                        if (MainActivity.randomCarNames.get(i2).equals(carMakes[randomCar])) {
                            randomCar = random.nextInt(images.length);
                        }
                    }
                }

                while (MainActivity.randomCars.contains(randomCar)) {
                    randomCar = random.nextInt(images.length);

                    if (i > 0) {
                        for (int i2 = 0; i2 < MainActivity.randomCarNames.size(); i2++) {
                            if (MainActivity.randomCarNames.get(i2).equals(carMakes[randomCar])) {
                                randomCar = random.nextInt(images.length);
                            }
                        }
                    }
                }

                MainActivity.randomCars.add(randomCar);
                MainActivity.randomCarNames.add(carMakes[randomCar]);

                if (i == 0) {
                    randomCar1 = randomCar;
                } else if (i == 1) {
                    randomCar2 = randomCar;
                } else {
                    randomCar3 = randomCar;
                }
            }

            randomMake = random.nextInt(3);
        }
        MainActivity.randomCarNames.clear();

        System.out.println(MainActivity.randomCars);
        System.out.println("------------------------------------------------------------Car 1 : " + carMakes[randomCar1] + " - " + randomCar1);
        System.out.println("------------------------------------------------------------Car 2 : " + carMakes[randomCar2] + " - " + randomCar2);
        System.out.println("------------------------------------------------------------Car 3 : " + carMakes[randomCar3] + " - " + randomCar3);

        carImg1.setImageResource(images[randomCar1]);
        carImg2.setImageResource(images[randomCar2]);
        carImg3.setImageResource(images[randomCar3]);

        if (randomMake == 0) {
            carMake.setText(carMakes[randomCar1]);
        } else if (randomMake == 1) {
            carMake.setText(carMakes[randomCar2]);
        } else if (randomMake == 2) {
            carMake.setText(carMakes[randomCar3]);
        }
        carMakeGenerated = carMake.getText().toString();
    }

    @SuppressLint("SetTextI18n")
    public void carImage1Click(View view) {

        ImageView carImg1 = (ImageView) findViewById(R.id.car_image_1);
        ImageView carImg2 = (ImageView) findViewById(R.id.car_image_2);
        ImageView carImg3 = (ImageView) findViewById(R.id.car_image_3);

        TextView carMake = (TextView) findViewById(R.id.car_make_image);
        TextView correctWrongImage = (TextView) findViewById(R.id.correct_wrong_image);
        TextView correctMakeImage = (TextView) findViewById(R.id.correct_make_image);

        if (MainActivity.imgCount == 0) {
            if (carMake.getText().equals(carMakes[randomCar1])) {
                correctWrongImage.setText("CORRECT!");
                correctWrongImage.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongImage.setText("WRONG!");
                correctWrongImage.setTextColor(Color.parseColor("#d10000"));

                correctMakeImage.setText("Correct image : " + (randomMake + 1));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                correctImgMake = correctMakeImage.getText().toString();
            }
            correctOrWrongClick = correctWrongImage.getText().toString();
        }

        clicked = 1;
        carImg1.setClickable(false);
        carImg2.setClickable(false);
        carImg3.setClickable(false);
    }

    @SuppressLint("SetTextI18n")
    public void carImage2Click(View view) {

        ImageView carImg1 = (ImageView) findViewById(R.id.car_image_1);
        ImageView carImg2 = (ImageView) findViewById(R.id.car_image_2);
        ImageView carImg3 = (ImageView) findViewById(R.id.car_image_3);

        TextView carMake = (TextView) findViewById(R.id.car_make_image);
        TextView correctWrongImage = (TextView) findViewById(R.id.correct_wrong_image);
        TextView correctMakeImage = (TextView) findViewById(R.id.correct_make_image);

        if (MainActivity.imgCount == 0) {
            if (carMake.getText().equals(carMakes[randomCar2])) {
                correctWrongImage.setText("CORRECT!");
                correctWrongImage.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongImage.setText("WRONG!");
                correctWrongImage.setTextColor(Color.parseColor("#d10000"));

                correctMakeImage.setText("Correct image : " + (randomMake + 1));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                correctImgMake = correctMakeImage.getText().toString();
            }
            correctOrWrongClick = correctWrongImage.getText().toString();
        }

        clicked = 1;
        carImg1.setClickable(false);
        carImg2.setClickable(false);
        carImg3.setClickable(false);
    }

    @SuppressLint("SetTextI18n")
    public void carImage3Click(View view) {

        ImageView carImg1 = (ImageView) findViewById(R.id.car_image_1);
        ImageView carImg2 = (ImageView) findViewById(R.id.car_image_2);
        ImageView carImg3 = (ImageView) findViewById(R.id.car_image_3);

        TextView carMake = (TextView) findViewById(R.id.car_make_image);
        TextView correctWrongImage = (TextView) findViewById(R.id.correct_wrong_image);
        TextView correctMakeImage = (TextView) findViewById(R.id.correct_make_image);

        if (MainActivity.imgCount == 0) {
            if (carMake.getText().equals(carMakes[randomCar3])) {
                correctWrongImage.setText("CORRECT!");
                correctWrongImage.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongImage.setText("WRONG!");
                correctWrongImage.setTextColor(Color.parseColor("#d10000"));

                correctMakeImage.setText("Correct image : " + (randomMake + 1));
                correctMakeImage.setTextColor(Color.parseColor("#bfb900"));
                correctImgMake = correctMakeImage.getText().toString();
            }
            correctOrWrongClick = correctWrongImage.getText().toString();
        }

        clicked = 1;
        carImg1.setClickable(false);
        carImg2.setClickable(false);
        carImg3.setClickable(false);
    }

    public void nextImage(View view) {

        MainActivity.imgCount = 0;
        if (MainActivity.randomCars.size() >= 30) {
            MainActivity.randomCars.clear();
            startActivity(new Intent(CarImageActivity.this, MainActivity.class));
        } else {
            startActivity(new Intent(CarImageActivity.this, CarImageActivity.class));
        }
    }
}