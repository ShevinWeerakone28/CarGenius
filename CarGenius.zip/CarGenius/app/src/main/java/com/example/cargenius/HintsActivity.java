package com.example.cargenius;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class HintsActivity extends AppCompatActivity {

    Random random = new Random();

    Integer[] images = {
            R.drawable.car_1,
            R.drawable.car_2,
            R.drawable.car_3,
            R.drawable.car_4,
            R.drawable.car_5,
            R.drawable.car_6,
            R.drawable.car_7,
            R.drawable.car_8,
            R.drawable.car_9,
            R.drawable.car_10,
            R.drawable.car_11,
            R.drawable.car_12,
            R.drawable.car_13,
            R.drawable.car_14,
            R.drawable.car_15,
            R.drawable.car_16,
            R.drawable.car_17,
            R.drawable.car_18,
            R.drawable.car_19,
            R.drawable.car_20,
            R.drawable.car_21,
            R.drawable.car_22,
            R.drawable.car_23,
            R.drawable.car_24,
            R.drawable.car_25,
            R.drawable.car_26,
            R.drawable.car_27,
            R.drawable.car_28,
            R.drawable.car_29,
            R.drawable.car_30,
    };

    String[] carMakes = {
            "Audi",
            "Audi",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Chevrolet",
            "Dodge",
            "Ford",
            "Honda",
            "Honda",
            "Koenigsegg",
            "Lamborghini",
            "Lamborghini",
            "Lamborghini",
            "Mazda",
            "Mazda",
            "McLaren",
            "McLaren",
            "Mercedes",
            "Mitsubishi",
            "Nissan",
            "Nissan",
            "Nissan",
            "Nissan",
            "Porsche",
            "Porsche",
            "Subaru",
            "Toyota",
            "Toyota",
            "Toyota"
    };

    int randomCar;
    String dashText = "";
    String editTextGuess = "";
    String submitText = "Submit";
    String correctOrWrongGuess = "";
    String correctMakeHints;
    long milliRemaining;

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("random_car", randomCar);
        bundle.putString("dash_text", dashText);
        bundle.putString("submit_text", submitText);
        bundle.putString("correct_wrong_guess", correctOrWrongGuess);
        bundle.putString("correct_make_hints", correctMakeHints);
        bundle.putLong("milli_remaining", milliRemaining);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hints);

        ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#c95500"));
        actionBar.setBackgroundDrawable(colorDrawable);

        final ImageView imgView = (ImageView) findViewById(R.id.car_make_img);
        TextView dashTextView = (TextView) findViewById(R.id.dash_text_view);
        Button submitGuess = (Button) findViewById(R.id.submit_hint);
        TextView correctWrongTextViewHints = (TextView) findViewById(R.id.correct_wrong_guess);
        TextView correctCarMakeHints = (TextView) findViewById(R.id.correct_car_make_hints);
        final TextView hintsTimer = (TextView) findViewById(R.id.hints_timer);

        if (MainActivity.randomGenerated.size() == 30) {
            MainActivity.randomGenerated.clear();
            startActivity(new Intent(HintsActivity.this, MainActivity.class));
        }

        if (savedInstanceState != null) {

            randomCar = savedInstanceState.getInt("random_car");
            dashText = savedInstanceState.getString("dash_text");
            submitText = savedInstanceState.getString("submit_text");
            correctOrWrongGuess = savedInstanceState.getString("correct_wrong_guess");
            correctMakeHints = savedInstanceState.getString("correct_make_hints");
            milliRemaining = savedInstanceState.getLong("milli_remaining");

            submitGuess.setText(submitText);
            correctWrongTextViewHints.setText(correctOrWrongGuess);
            correctCarMakeHints.setText(correctMakeHints);

            if (MainActivity.switchOn == 1) {

                new CountDownTimer(milliRemaining, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        hintsTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        hintsTimer.setText("Time Up!");
                        hintsCountdownTimer();

                        if (carMakes[randomCar].equalsIgnoreCase(dashText)) {
                            correctWrongTextViewHints.setText("CORRECT!");
                            correctWrongTextViewHints.setTextColor(Color.parseColor("#07d100"));
                        } else {
                            correctWrongTextViewHints.setText("WRONG!");
                            correctWrongTextViewHints.setTextColor(Color.parseColor("#d10000"));

                            correctCarMakeHints.setText("Correct car make : " + carMakes[randomCar]);
                            correctMakeHints = correctCarMakeHints.getText().toString();
                            correctCarMakeHints.setTextColor(Color.parseColor("#bfb900"));
                        }
                        correctOrWrongGuess = correctWrongTextViewHints.getText().toString();
                        submitGuess.setText("Next");
                        submitText = submitGuess.getText().toString();
                    }
                }.start();
            }

            if (correctWrongTextViewHints.getText().equals("CORRECT!")) {
                correctWrongTextViewHints.setTextColor(Color.parseColor("#07d100"));
            } else {
                correctWrongTextViewHints.setTextColor(Color.parseColor("#d10000"));
                correctCarMakeHints.setTextColor(Color.parseColor("#bfb900"));
            }
        } else {

            if (MainActivity.switchOn == 1) {
                new CountDownTimer(20000, 1000) {

                    @SuppressLint("SetTextI18n")
                    public void onTick(long millisUntilFinished) {
                        hintsTimer.setText("Timer : " + millisUntilFinished / 1000);
                        milliRemaining = millisUntilFinished;
                    }

                    @SuppressLint("SetTextI18n")
                    public void onFinish() {
                        hintsTimer.setText("Time Up!");
                        hintsCountdownTimer();

                        if (carMakes[randomCar].equalsIgnoreCase(dashText)) {
                            correctWrongTextViewHints.setText("CORRECT!");
                            correctWrongTextViewHints.setTextColor(Color.parseColor("#07d100"));
                        } else {
                            correctCarMakeHints.setText("Correct car make : " + carMakes[randomCar]);
                            correctMakeHints = correctCarMakeHints.getText().toString();
                            correctCarMakeHints.setTextColor(Color.parseColor("#bfb900"));

                            correctWrongTextViewHints.setText("WRONG!");
                            correctWrongTextViewHints.setTextColor(Color.parseColor("#d10000"));
                        }
                        correctOrWrongGuess = correctWrongTextViewHints.getText().toString();
                        submitGuess.setText("Next");
                        submitText = submitGuess.getText().toString();
                    }
                }.start();
            }

            randomCar = random.nextInt(images.length);

            while (MainActivity.randomGenerated.contains(randomCar)) {
                randomCar = random.nextInt(images.length);
            }

            MainActivity.randomGenerated.add(randomCar);

            for (int i = 0; i < carMakes[randomCar].length(); i++) {
                dashText += "-";
            }

        }
        dashTextView.setText(dashText);

        imgView.setImageResource(images[randomCar]);
    }

    @SuppressLint("SetTextI18n")
    public void hintsCountdownTimer() {

        EditText hintEditText = (EditText) findViewById(R.id.car_make_letter);
        TextView dashTextView = (TextView) findViewById(R.id.dash_text_view);
        TextView correctWrongGuess = (TextView) findViewById(R.id.correct_wrong_guess);
        Button submitNextHint = (Button) findViewById(R.id.submit_hint);

        editTextGuess = hintEditText.getText().toString();
        submitText = submitNextHint.getText().toString();

        if (submitNextHint.getText().equals("Submit")) {

            for (int h = 0; h < dashText.length(); h++) {
                MainActivity.hintDashes.add(String.valueOf(dashText.charAt(h)));
            }

            dashText = "";

            for (int i = 0; i < carMakes[randomCar].length(); i++) {

                if (editTextGuess.equalsIgnoreCase(String.valueOf(carMakes[randomCar].charAt(i)))) {
                    dashText += String.valueOf(carMakes[randomCar].charAt(i)).toUpperCase();
                } else {
                    MainActivity.guessNotPresent += 1;
                    dashText += MainActivity.hintDashes.get(i);
                }
            }
            System.out.println("Guess Not Present ----------------------------- " + MainActivity.guessNotPresent);
            MainActivity.hintDashes.clear();
            dashTextView.setText(dashText);

            if (MainActivity.guessNotPresent == carMakes[randomCar].length()) {
                MainActivity.invalidGuesses += 1;
            }

            if (MainActivity.invalidGuesses == 3) {
                correctWrongGuess.setText("WRONG!");
                correctWrongGuess.setTextColor(Color.parseColor("#d10000"));
                correctOrWrongGuess = correctWrongGuess.getText().toString();

                TextView correctCarMakeHints = (TextView) findViewById(R.id.correct_car_make_hints);
                correctCarMakeHints.setText("Correct car make : " + carMakes[randomCar]);
                correctMakeHints = correctCarMakeHints.getText().toString();
                correctCarMakeHints.setTextColor(Color.parseColor("#bfb900"));

                submitNextHint.setText("Next");
                submitText = submitNextHint.getText().toString();
            }

            if (carMakes[randomCar].equalsIgnoreCase(dashText)) {
                correctWrongGuess.setText("CORRECT!");
                correctWrongGuess.setTextColor(Color.parseColor("#07d100"));
                correctOrWrongGuess = correctWrongGuess.getText().toString();

                submitNextHint.setText("Next");
                submitText = submitNextHint.getText().toString();
            }

            MainActivity.guessNotPresent = 0;
        }
    }

    @SuppressLint("SetTextI18n")
    public void submitHintGuess(View view) {

        EditText hintEditText = (EditText) findViewById(R.id.car_make_letter);
        TextView dashTextView = (TextView) findViewById(R.id.dash_text_view);
        TextView correctWrongGuess = (TextView) findViewById(R.id.correct_wrong_guess);
        Button submitNextHint = (Button) findViewById(R.id.submit_hint);

        editTextGuess = hintEditText.getText().toString();
        submitText = submitNextHint.getText().toString();

        if (submitNextHint.getText().equals("Submit")) {

            for (int h = 0; h < dashText.length(); h++) {
                MainActivity.hintDashes.add(String.valueOf(dashText.charAt(h)));
            }

            dashText = "";

            for (int i = 0; i < carMakes[randomCar].length(); i++) {

                if (editTextGuess.equalsIgnoreCase(String.valueOf(carMakes[randomCar].charAt(i)))) {
                    dashText += String.valueOf(carMakes[randomCar].charAt(i)).toUpperCase();
                } else {
                    MainActivity.guessNotPresent += 1;
                    dashText += MainActivity.hintDashes.get(i);
                }
            }
            System.out.println("Guess Not Present ----------------------------- " + MainActivity.guessNotPresent);
            MainActivity.hintDashes.clear();
            dashTextView.setText(dashText);

            if (MainActivity.guessNotPresent == carMakes[randomCar].length()) {
                MainActivity.invalidGuesses += 1;
            }

            if (MainActivity.invalidGuesses == 3) {
                correctWrongGuess.setText("WRONG!");
                correctWrongGuess.setTextColor(Color.parseColor("#d10000"));
                correctOrWrongGuess = correctWrongGuess.getText().toString();

                TextView correctCarMakeHints = (TextView) findViewById(R.id.correct_car_make_hints);
                correctCarMakeHints.setText("Correct car make : " + carMakes[randomCar]);
                correctMakeHints = correctCarMakeHints.getText().toString();
                correctCarMakeHints.setTextColor(Color.parseColor("#bfb900"));

                submitNextHint.setText("Next");
                submitText = submitNextHint.getText().toString();
            }

            if (carMakes[randomCar].equalsIgnoreCase(dashText)) {
                correctWrongGuess.setText("CORRECT!");
                correctWrongGuess.setTextColor(Color.parseColor("#07d100"));
                correctOrWrongGuess = correctWrongGuess.getText().toString();

                submitNextHint.setText("Next");
                submitText = submitNextHint.getText().toString();
            }

            MainActivity.guessNotPresent = 0;
        } else {
            MainActivity.invalidGuesses = 0;
            startActivity(new Intent(HintsActivity.this, HintsActivity.class));
        }
    }
}